package com.example.fit2081_remade;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private EditText etTitle, etyear, etcountry, etgenre, etcost, etkey;

    private final List<String> movies = new ArrayList<>();
    private ArrayAdapter<String> adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//recyler view in fragment or seperate activity. recyler would use set card in the . recycler
        etTitle = findViewById(R.id.et_title);
        etyear = findViewById(R.id.et_year);
        etcountry = findViewById(R.id.et_country);
        etgenre = findViewById(R.id.et_genre);
        etcost = findViewById(R.id.et_cost);
        etkey = findViewById(R.id.et_key);

        ListView movielistview = findViewById(R.id.list_view);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, movies);
        movielistview.setAdapter(adapter);



        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addMovie();
                Snackbar.make(view, "Item added to list", Snackbar.LENGTH_LONG).setAction("Undo", undoOnClickListener).show();
            }
        });

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }
    View.OnClickListener undoOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            removeLastMovie();
        }

    };
    private void addMovie() {
        String title = String.valueOf(etTitle.getText()).trim();
        String year = String.valueOf(etyear.getText()).trim();
        String country = String.valueOf(etcountry.getText()).trim();
        String genre = String.valueOf(etgenre.getText()).trim();
        String cost = String.valueOf(etcost.getText()).trim();
        String key = String.valueOf(etkey.getText()).trim();

        if(title.isEmpty()||year.isEmpty()||country.isEmpty()||genre.isEmpty()||cost.isEmpty()||key.isEmpty()){
            Toast.makeText(this,"something is missing",Toast.LENGTH_LONG).show();
            return;
        };
        int counter = movies.size();
        String movie = String.format(Locale.ROOT,"%d | %S | %S| %S| %S| %S", ++counter,title, year, country, genre, cost, key);
        movies.add(movie);
        adapter.notifyDataSetChanged();

    }

    private void removeLastMovie(){
        if(movies.isEmpty()){
            Toast.makeText(this,"movie emptied, enter movie first",Toast.LENGTH_LONG).show();
            return;
        }

        movies.clear();
        adapter.notifyDataSetChanged();
    }

    private void setdefaultmovie() {
        etTitle.setText("movie title");
        etyear.setText("year");
        etcountry.setText("country");
        etgenre.setText("genre");
        etcost.setText("price");
        etkey.setText("key word");
    }

    {

    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            clearFields();
            return true;
        }
        if (id == R.id.discount) {
            int cutoff = Integer.parseInt(String.valueOf(etcost));
            cutoff = cutoff/10*100;
            etcost.setText(String.valueOf(cutoff));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void clearFields() {
        etTitle.setText(null);
        etyear.setText(null);
        etcountry.setText(null);
        etgenre.setText(null);
        etcost.setText(null);
        etkey.setText(null);
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            // add movie
            addMovie();
        } else if (id == R.id.nav_gallery) {
            // remove previous movie
            removeLastMovie();
        } else if (id == R.id.nav_slideshow) {
            //clear all
            removeAllMovie();
        }
        else if (id == R.id.nav_set_default) {
            //clear all
            setdefaultmovie();
        }//add menu here, redirect the fragmebt
        else if (id == R.id.nav_set_list) {
            getSupportFragmentManager().beginTransaction().add(R.id.fig,new BlankFragment()).addToBackStack("f1").commit();

            //fragment happened here
            //or intent - recycler view
        }//add menu here, redirect the fragmebt


        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void removeAllMovie() {
        movies.remove(movies.size() -1);
        adapter.notifyDataSetChanged();
    }



}