package com.example.fit2081_remade;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class adapter extends RecyclerView.Adapter<adapter.MyViewHolder>{

    ArrayList<String> ds;//conect the data here so you could make the fungtion in the main activity
    public adapter(ArrayList<String> ds){
        this.ds = ds;
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) { //scroll
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.card_layout,parent,false);//add the conection ot the xml card layout
        MyViewHolder holder = new MyViewHolder(v);//each time it create card it add the data to the card, holder is the container
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull adapter.MyViewHolder holder, int position) {//what data to bind in the arraylist
        holder.ctitle.setText(ds.get(position));
        holder.cyear.setText(ds.get(position));
        holder.ccost.setText(ds.get(position));
        holder.ccountry.setText(ds.get(position));
        holder.cgenre.setText(ds.get(position));
        holder.ckey.setText(ds.get(position));

    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView ctitle;
        TextView cyear;
        TextView ccost;
        TextView ccountry;
        TextView cgenre;
        TextView ckey;
        TextView cconvert;


        public MyViewHolder(@NonNull View itemView) {//
            super(itemView);
            ctitle=itemView.findViewById(R.id.titleC);
            cyear=itemView.findViewById(R.id.yearC);
            ccost=itemView.findViewById(R.id.costC);
            ccountry=itemView.findViewById(R.id.countryC);
            cgenre=itemView.findViewById(R.id.genreC);
            ckey=itemView.findViewById(R.id.keyC);
            cconvert=itemView.findViewById(R.id.convertC);

        }
    }
}
