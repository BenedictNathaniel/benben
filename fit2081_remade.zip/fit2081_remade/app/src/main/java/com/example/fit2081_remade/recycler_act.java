package com.example.fit2081_remade;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class recycler_act extends AppCompatActivity {

    ArrayList<String> dataScource;
    adapter ad;
    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler);

        recyclerView = findViewById(R.id.fig);
        layoutManager=new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        dataScource=new ArrayList<>();
        ad =new adapter(dataScource);
        recyclerView.setAdapter(ad);
    }
    public void onAddItemBtnClick(View view){//idk

    }

}